How use programm:

1.Start the programm  on MacOS with Xcode
2.Enter required information
3.Wait for completion
4.Select numbers (command + A) and save there, where you want