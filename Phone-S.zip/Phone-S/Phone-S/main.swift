
//  _     _       _       _
// / \| || ||  /||       /
// |/ |-|| || / ||-  --  \
// |  | ||_||/  ||_     _/

import Foundation

//variables

var programmWillWork = true

//functions

func emptyCalculator(inputNum: Int) -> String {
    var empty: String
    var checkVar: Int = 0
    for _ in String(inputNum){
        checkVar += 1
    }
    if checkVar == 1{
        empty = "0"
    }else{
        empty = ""
    }
    return empty
}

func printArray(array: [Any]) -> Void {
    for i in array{
        print(i)
    }
}

func input() -> [Int] {
    var array: [Int] = []
    print("from:")
    let fromInput: String? = readLine()
    if let fromInput = Int(fromInput!){
        array.append(Int(fromInput))
    }else{
        print("Input error. Please restart programm and try again")
        programmWillWork = false
    }
    print("to:")
    let toInput: String? = readLine()
    if let toInput = Int(toInput!){
        array.append(Int(toInput))
    }else{
        print("Input error. Please restart programm and try again")
        programmWillWork = false
    }
    
    return array
    
}

func reSelect(regionCode: [Int], digitsFirst: [Int], digitsMid: [Int], digitsLast: [Int], countryCode: String?, numType: Bool) -> [String] {
    var numbers: [String] = []
    for regionCode in regionCode[0]...regionCode[1]{
        for firstDigits in digitsFirst[0]...digitsFirst[1]{
            for midDigits in digitsMid[0]...digitsMid[1]{
                for lastDigits in digitsLast[0]...digitsLast[1]{
                    var emptyFD = ""
                    var checkFDvar = 0
                    for _ in String(firstDigits){
                        checkFDvar += 1
                    }
                    if checkFDvar == 1{
                        emptyFD = "00"
                    }else if checkFDvar == 2{
                        emptyFD = "0"
                    }else{
                        emptyFD = ""
                    }
                    let emptyMD = emptyCalculator(inputNum: midDigits)
                    let emptyLD = emptyCalculator(inputNum: lastDigits)
                    //init
                    if numType{
                        var chars: [Character] = []
                        for char in countryCode!{
                            if char == "+"{
                                continue
                            }else{
                                chars.append(char)
                            }
                        }
                        var charNum: String = ""
                        for char in chars{
                            charNum += String(char)
                        }
                        numbers.append("\(charNum)\(regionCode)\(emptyFD)\(firstDigits)\(emptyMD)\(midDigits)\(emptyLD)\(lastDigits)")
                    }else{
                        numbers.append("\(countryCode!)(\(regionCode))\(emptyFD)\(firstDigits)-\(emptyMD)\(midDigits)-\(emptyLD)\(lastDigits)")
                    }
                }
            }
        }
    }
    return numbers
}

func main() -> Void {
    
    print("Enter phone country code (+1, +2, +7)")
    let countryCode: String? = readLine()
    
    print("Enter region code")
    let regionCode = input()
    
    print("Enter first 3 phone digits (xxx-##-##)")
    let digitsFirst = input()
    
    print("Enter mid 2 phone digits (###-xx-##)")
    let digitsMid = input()
    
    print("enter last 2 phone digits (###-##-xx)")
    let digitsLast = input()
    
    print("Save phones as numbers? (y/n)")
    let wanting: String? = readLine()
    var numType: Bool = false
    if wanting == "y"{
        numType = true
    }else{
        numType = false
    }
    
    print("Wait for...")
    
    var phones: [String] = []
    
    if programmWillWork{
        phones = reSelect(regionCode: regionCode, digitsFirst: digitsFirst, digitsMid: digitsMid, digitsLast: digitsLast, countryCode: countryCode, numType: numType)
        printArray(array: phones)
        print("Succesful")
    }else{
        print("Programm ended with error")
    }
}

//main

print(" ========== Phone-S ========== \nprogramm version: v0.1")

main()
